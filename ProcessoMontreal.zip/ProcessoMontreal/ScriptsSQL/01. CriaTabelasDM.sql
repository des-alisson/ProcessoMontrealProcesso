--Script de criação de todas as tabelas

CREATE TABLE td_produto (
    sk_produto    BIGINT identity(1,1) NOT NULL,
    id_produto    BIGINT NOT NULL,
    nm_produto    VARCHAR(150),
    fl_situacao   VARCHAR(10) NOT NULL
)
ALTER TABLE TD_PRODUTO ADD constraint td_produto_pk PRIMARY KEY CLUSTERED (SK_PRODUTO)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON ) 

CREATE TABLE td_assinante (
    sk_assinante            BIGINT identity(1,1) NOT NULL,
    nr_telefone             BIGINT NOT NULL,
    fl_reutiliza_servico         VARCHAR(30) NOT NULL
)

ALTER TABLE TD_ASSINANTE ADD constraint td_assinante_pk PRIMARY KEY CLUSTERED (SK_ASSINANTE)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )

CREATE TABLE td_assinatura (
    sk_assinatura           BIGINT identity(1,1) NOT NULL,
    id_assinatura           BIGINT NOT NULL,
    fl_pagamento_pendente   VARCHAR(3) NOT NULL,
    fl_situacao             VARCHAR(10) NOT NULL
)

ALTER TABLE TD_ASSINATURA ADD constraint td_assinatura_pk PRIMARY KEY CLUSTERED (SK_ASSINATURA)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )

CREATE TABLE td_regiao (
    sk_regiao   BIGINT identity(1,1) NOT NULL,
    id_regiao   BIGINT NOT NULL,
    nm_regiao   VARCHAR(100) NOT NULL,
    nm_uf       VARCHAR(2) NOT NULL,
    nm_cidade   VARCHAR(100) NOT NULL
)
ALTER TABLE TD_REGIAO ADD constraint td_regiao_pk PRIMARY KEY CLUSTERED (SK_REGIAO)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON ) 

CREATE TABLE td_tempo (
    sk_tempo              BIGINT identity(1,1) NOT NULL,
    data                  DATE NOT NULL,
    nr_ano                SMALLINT NOT NULL,
    nr_mes                SMALLINT NOT NULL,
    nr_dia                SMALLINT NOT NULL,
    nr_dia_semana         SMALLINT NOT NULL,
    nm_dia_semana         VARCHAR(30) NOT NULL,
    nm_dia_semana_abrev   VARCHAR(15) NOT NULL,
    nm_mes                VARCHAR(30) NOT NULL,
    nm_mes_abrev          VARCHAR(15) NOT NULL
)
ALTER TABLE TD_TEMPO ADD constraint td_tempo_pk PRIMARY KEY CLUSTERED (SK_TEMPO)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON ) 

CREATE TABLE tf_assinatura (
    sk_assinatura        BIGINT NOT NULL,
    sk_assinante         BIGINT NOT NULL,
    sk_regiao            BIGINT NOT NULL,
    sk_produto           BIGINT NOT NULL,
    sk_dt_assinatura     BIGINT NOT NULL,
    sk_dt_cancelamento   BIGINT,
    qtd_tarifacao        BIGINT,
    vl_tarifacao         NUMERIC(10,5),
    dt_referencia        DATE NOT NULL
)

ALTER TABLE TF_ASSINATURA
    ADD CONSTRAINT tf_assinatura_td_assinante_fk FOREIGN KEY ( sk_assinante )
        REFERENCES td_assinante ( sk_assinante )
ON DELETE NO ACTION 
    ON UPDATE no action go

ALTER TABLE TF_ASSINATURA
    ADD CONSTRAINT tf_assinatura_td_assinatura_fk FOREIGN KEY ( sk_assinatura )
        REFERENCES td_assinatura ( sk_assinatura )
ON DELETE NO ACTION 
    ON UPDATE no action go

ALTER TABLE TF_ASSINATURA
    ADD CONSTRAINT tf_assinatura_td_produto_fk FOREIGN KEY ( sk_produto )
        REFERENCES td_produto ( sk_produto )
ON DELETE NO ACTION 
    ON UPDATE no action go

ALTER TABLE TF_ASSINATURA
    ADD CONSTRAINT tf_assinatura_td_regiao_fk FOREIGN KEY ( sk_regiao )
        REFERENCES td_regiao ( sk_regiao )
ON DELETE NO ACTION 
    ON UPDATE no action go

ALTER TABLE TF_ASSINATURA
    ADD CONSTRAINT tf_assinatura_td_tempo_fkv1 FOREIGN KEY ( sk_dt_assinatura )
        REFERENCES td_tempo ( sk_tempo )
ON DELETE NO ACTION 
    ON UPDATE no action go

ALTER TABLE TF_ASSINATURA
    ADD CONSTRAINT tf_assinatura_td_tempo_fkv2 FOREIGN KEY ( sk_dt_cancelamento )
        REFERENCES td_tempo ( sk_tempo )
ON DELETE NO ACTION 
    ON UPDATE no action go


--Insere -1 e -2 nas dimensões
SET IDENTITY_INSERT DM_CodeChallenge.dbo.td_assinante on;       
INSERT INTO DM_CodeChallenge.dbo.td_assinante (sk_assinante, nm_telefone, fl_reutiliza_servico) VALUES(-2, -2, 'Não se aplica');
INSERT INTO DM_CodeChallenge.dbo.td_assinante (sk_assinante, nm_telefone, fl_reutiliza_servico) VALUES(-1, -1, 'Não identificado');
SET IDENTITY_INSERT DM_CodeChallenge.dbo.td_assinante off;

SET IDENTITY_INSERT DM_CodeChallenge.dbo.td_assinatura on;       
INSERT INTO DM_CodeChallenge.dbo.td_assinatura (sk_assinatura, id_assinatura, fl_pagamento_pendente, fl_situacao) VALUES(-2, -2, '-2', '-2');
INSERT INTO DM_CodeChallenge.dbo.td_assinatura (sk_assinatura, id_assinatura, fl_pagamento_pendente, fl_situacao) VALUES(-1, -1, '-1', '-1');
SET IDENTITY_INSERT DM_CodeChallenge.dbo.td_assinatura off;

SET IDENTITY_INSERT DM_CodeChallenge.dbo.td_produto on;       
INSERT INTO DM_CodeChallenge.dbo.td_produto (sk_produto, id_produto, nm_produto, fl_situacao) VALUES(-2, -2, 'Não se aplica', -2);
INSERT INTO DM_CodeChallenge.dbo.td_produto (sk_produto, id_produto, nm_produto, fl_situacao) VALUES(-1, -1, 'Não identificado', -1);
SET IDENTITY_INSERT DM_CodeChallenge.dbo.td_produto off;

SET IDENTITY_INSERT DM_CodeChallenge.dbo.td_regiao on;       
INSERT INTO DM_CodeChallenge.dbo.td_regiao (sk_regiao, id_regiao, nm_regiao, nm_uf, nm_cidade) VALUES(-2, -2, 'Não se aplica', '-2', 'Não se aplica');
INSERT INTO DM_CodeChallenge.dbo.td_regiao (sk_regiao, id_regiao, nm_regiao, nm_uf, nm_cidade) VALUES(-1, -1, 'Não identificado', '-1', 'Não identificado');
SET IDENTITY_INSERT DM_CodeChallenge.dbo.td_regiao off;

