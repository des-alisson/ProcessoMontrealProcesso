--FT Assinatura
SELECT 
	CAST(ASS.ID_Assinatura AS BIGINT) ID_ASSINATURA
	, CAST(ass.Numero_Tel AS BIGINT) NR_TELEFONE
	, CAST(ASS.[DDD] AS BIGINT) ID_REGIAO
	, CAST(ASS.[ID_Produto] AS BIGINT) ID_PRODUTO
	, CAST(ASS.[Dt_Assinatura] AS DATE) DT_ASSINATURA
	, CAST(ASS.[Dt_Cancelamento] AS DATE) DT_CANCELAMENTO
	, CAST(CASE WHEN ASS.Status_Assinatura = 0 THEN 1 ELSE 0 END AS bigint) QTD_CANCELAMENTO
	, CAST(CASE WHEN ASS.Status_Assinatura = 1 THEN 1 ELSE 0 END AS bigint) QTD_ATIVO
	, CAST(CASE WHEN ASS.Pendente = 1 THEN 1 ELSE 0 END AS bigint) QTD_PENDENTE
	, SUM(CASE WHEN TRANS.Status_transacao = 1 THEN 1 ELSE 0 END) QTD_TARIFACAO
	, SUM(CAST((CASE WHEN TRANS.Status_transacao = 1 THEN TRANS.Valor ELSE 0 END) AS NUMERIC(10,5))) AS VL_PRODUTO
	, DATEDIFF(DAY, ULTTRANS.Dt_Transacao, ?) QTD_DIAS_SEM_TARIFAR
	, CAST(? AS DATE) DT_REFERENCIA
FROM 
	CodeChallenge..tblAssinatura ASS
		LEFT JOIN CodeChallenge..tblTransacao AS TRANS ON
			TRANS.ID_Assinatura = ASS.ID_Assinatura
		LEFT JOIN (	SELECT 
						ID_Assinatura, 
						MAX(Dt_Transacao) Dt_Transacao 
					FROM 
						CodeChallenge..tblTransacao 
					WHERE
						Status_transacao = 1
					GROUP BY 
						ID_Assinatura
					) ULTTRANS ON
			ULTTRANS.ID_Assinatura = ASS.ID_Assinatura
WHERE
	1=1
	AND cast(TRANS.Dt_Transacao AS date) BETWEEN CAST(DATEADD(DAY, -30, ?) AS DATE) AND CAST(? AS DATE)
GROUP BY
	CAST(ASS.ID_Assinatura AS BIGINT)
	, CAST(ASS.Numero_Tel AS BIGINT)
	, CAST(ASS.[DDD] AS BIGINT)
	, CAST(ASS.[ID_Produto] AS BIGINT)
	, CAST(ASS.[Dt_Assinatura] AS DATE)
	, CAST(ASS.[Dt_Cancelamento] AS DATE)
	, CAST(CASE WHEN ASS.Status_Assinatura = 0 THEN 1 ELSE 0 END AS bigint)
	, CAST(CASE WHEN ASS.Status_Assinatura = 1 THEN 1 ELSE 0 END AS bigint)
	, CAST(CASE WHEN ASS.Pendente = 1 THEN 1 ELSE 0 END AS bigint)
	, ULTTRANS.Dt_Transacao
;

--Dimensão Assinante
SELECT DISTINCT    
	  cast(ASSINANTE.Numero_Tel AS BIGINT) NR_TELEFONE
	, CASE WHEN ASSINOU.FL_REUTILIZOU = 1 THEN 'Sim' ELSE 'Não' END FL_REUTILIZA_SERVICO
FROM            
	CodeChallenge.dbo.tblAssinatura AS ASSINANTE	
		LEFT JOIN	(
						SELECT 
							ATIVAS.Numero_tel
							, MAX(CASE WHEN CANCELADAS.Dt_Assinatura IS NOT NULL THEN 1 ELSE 0 END) FL_REUTILIZOU

						FROM 
							CodeChallenge..tblAssinatura ATIVAS
								LEFT JOIN	(
												SELECT 
													Numero_tel
													, CAST(Dt_Assinatura AS DATE) Dt_Assinatura
													, CAST(Dt_Cancelamento AS DATE) Dt_Cancelamento
												FROM 
													CodeChallenge..tblAssinatura
												WHERE
													Dt_Cancelamento IS NOT NULL
											) CANCELADAS ON
									CANCELADAS.Numero_tel = ATIVAS.Numero_tel
									AND CAST(ATIVAS.Dt_Assinatura AS DATE) > CANCELADAS.Dt_Cancelamento
						GROUP BY
							ATIVAS.Numero_tel
									
					) ASSINOU ON
			ASSINOU.Numero_tel = ASSINANTE.Numero_Tel
;

--Dimensão Assinatura
SELECT    
	  cast(ASSINATURA.ID_Assinatura AS BIGINT) ID_ASSINATURA
	, CASE WHEN ASSINATURA.Pendente = 1 THEN 'Sim' ELSE 'Não' END FL_PAGAMENTO_PENDENTE
	, CASE WHEN ASSINATURA.Status_Assinatura = 1 THEN 'Ativo' ELSE 'Inativo' END FL_SITUACAO
FROM            
	CodeChallenge.dbo.tblAssinatura AS ASSINATURA
;

--Dimensão Produto
SELECT
	  cast(PRD.ID_Produto as bigint) ID_PRODUTO
	, cast(PRD.Nome_Produto as varchar(100)) NM_PRODUTO
	, case when PRD.Status_Produto = 1 then 'Ativo' else 'Inativo' end FL_STATUS
FROM 
	CodeChallenge..tblProduto PRD
;

--Dimensão Regiao
SELECT
	 CAST(DDD AS BIGINT) ID_REGIAO
	, cast(cidade as varchar(100)) NM_CIDADE
	, Estado NM_UF
	, CAST(
		CASE
			WHEN Estado IN ('AM', 'RR', 'AP', 'PA', 'TO', 'RO', 'AC') THEN 'Região Norte'
			WHEN Estado IN ('MA', 'PI', 'CE', 'RN', 'PE', 'PB', 'SE', 'AL', 'BA') THEN 'Região Nordeste'
			WHEN Estado IN ('MT', 'MS', 'GO', 'DF') THEN 'Região Centro-Oeste'
			WHEN Estado IN ('SP', 'RJ', 'ES', 'MG') THEN 'Região Sudeste'
			WHEN Estado IN ('PR', 'RS', 'SC') THEN 'Região Sul'
			ELSE NULL
		END AS VARCHAR(100)) NM_REGIAO
FROM
	tblDDD